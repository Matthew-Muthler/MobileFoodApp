package com.cmsc.lowerbentleymobileapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class FoodItemsAdapter extends RecyclerView.Adapter<FoodItemsAdapter.ViewHolder> {
    ArrayList<FoodItems> foodItems;

    public FoodItemsAdapter(ArrayList<FoodItems> foodItems) {
        this.foodItems = foodItems;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_fooditems,parent,false);
        return new ViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodItemsAdapter.ViewHolder holder, int position) {
        holder.foodItemsName.setText(foodItems.get(position).getFoodTitle());
        String picUrl = foodItems.get(position).getPic();
        holder.mainLayout.setBackground(ContextCompat.getDrawable(holder.itemView.getContext(), R.drawable.itembackground1));


        int drawableResourceId = holder.itemView.getContext().getResources().getIdentifier(picUrl,"drawable",holder.itemView.getContext().getPackageName());
        Glide.with(holder.itemView.getContext())
                .load(drawableResourceId)
                .into(holder.foodItemsPic);
    }

    @Override
    public int getItemCount() {
        return foodItems.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView foodItemsName;
        ImageView foodItemsPic;
        ConstraintLayout mainLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            foodItemsName = itemView.findViewById(R.id.foodItemName);
            foodItemsPic = itemView.findViewById(R.id.foodItemPic);
            mainLayout = itemView.findViewById(R.id.foodItemLayout);
        }
    }
}
