package com.cmsc.lowerbentleymobileapp;

import androidx.appcompat.app.AppCompatActivity;

public class FoodItems extends AppCompatActivity {
    private String foodTitle;
    private String pic;

    public FoodItems(String foodTitle, String pic) {
        this.foodTitle = foodTitle;
        this.pic = pic;
    }

    public String getFoodTitle() {
        return foodTitle;
    }

    public void setFoodTitle(String foodTitle) {
        this.foodTitle = foodTitle;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }
}
